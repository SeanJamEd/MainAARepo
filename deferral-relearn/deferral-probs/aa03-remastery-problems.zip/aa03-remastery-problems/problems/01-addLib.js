/***********************************************************************
Write a function makeAddLib(verb, adj, noun) that accepts three strings.

Use string interpolation to return a new wacky string using the three string args.  See the examples for more information.

console.log(makeAddLib("swim", "sparkly", "rainbow")); // => "I shall swim to the sparkly rainbow?"
console.log(makeAddLib("RUN", "FANCY", "ParK")); // => "I shall RUN to the FANCY ParK?"

***********************************************************************/


function makeAddLib(verb, adj, noun) {
  // Your code here 
  return `I shall ${verb} to the ${adj} ${noun}?`
}


/**************DO NOT MODIFY ANYTHING UNDER THIS LINE*****************/
try {
  module.exports = makeAddLib;
} catch (e) {
  module.exports = null;
}
